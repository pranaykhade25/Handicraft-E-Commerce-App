package com.example.handicraftecommerceapplication;

public class Order_POJO {

    String Buildingname,City,Email,Fullname,Ordered_Product,Payment_Mode,Phonenumber,Pincode,Roadname,Size,State;

    public String getState() {
        return State;
    }

    public void setState(String state) {
        State = state;
    }

    public String getBuildingname() {
        return Buildingname;
    }

    public void setBuildingname(String buildingname) {
        Buildingname = buildingname;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getFullname() {
        return Fullname;
    }

    public void setFullname(String fullname) {
        Fullname = fullname;
    }

    public String getOrdered_Product() {
        return Ordered_Product;
    }

    public void setOrdered_Product(String ordered_Product) {
        Ordered_Product = ordered_Product;
    }

    public String getPayment_Mode() {
        return Payment_Mode;
    }

    public void setPayment_Mode(String payment_Mode) {
        Payment_Mode = payment_Mode;
    }

    public String getPhonenumber() {
        return Phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        Phonenumber = phonenumber;
    }

    public String getPincode() {
        return Pincode;
    }

    public void setPincode(String pincode) {
        Pincode = pincode;
    }

    public String getRoadname() {
        return Roadname;
    }

    public void setRoadname(String roadname) {
        Roadname = roadname;
    }

    public String getSize() {
        return Size;
    }

    public void setSize(String size) {
        Size = size;
    }
}
